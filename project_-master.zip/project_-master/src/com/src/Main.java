package com.src;

public class Main {
    public static void main(String[] args) throws Exception {
        Interface anInterface = new Interface();
        anInterface.Calculate();
       // PathCheck pathCheck = new PathCheck("/IdeaProjects/project_/testFile.rtf");
    }
}